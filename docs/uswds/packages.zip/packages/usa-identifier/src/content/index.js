export { default as DefaultContent } from "./usa-identifier.json";
export { default as EsContent } from "./usa-identifier~lang-es.json";
export { default as MultipleLogosContent } from "./usa-identifier~multiple-logos.json";
export { default as EsMultipleLogosContent } from "./usa-identifier~multiple-logos-lang-es.json";
export { default as NoLogosContent } from "./usa-identifier~no-logos.json";
export { default as EsNoLogosContent } from "./usa-identifier~no-logos-lang-es.json";
export { default as TaxpayerContent } from "./usa-identifier~taxpayer-disclaimer.json";
export { default as EsTaxpayerContent } from "./usa-identifier~taxpayer-disclaimer-lang-es.json";
