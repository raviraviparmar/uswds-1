export { default as DefaultContent } from "./usa-search.json";
export { default as DefaultContentLangEs } from "./usa-search~lang-es.json";
export { default as BigContent } from "./usa-search~big.json";
export { default as BigContentLangEs } from "./usa-search~big-lang-es.json";
export { default as SmallContent } from "./usa-search~small.json";
export { default as SmallContentLangEs } from "./usa-search~small-lang-es.json";
