export { default as DefaultContent } from "./usa-banner.json";
export { default as DefaultContentLangEs } from "./usa-banner~lang-es.json";
export { default as MilContent } from "./usa-banner~mil.json";
export { default as MilContentLangEs } from "./usa-banner~mil-lang-es.json";
