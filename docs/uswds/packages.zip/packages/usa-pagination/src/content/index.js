export { default as DefaultContent } from "./usa-pagination.json";
export { default as UnboundedContent } from "./usa-pagination~unbounded.json";
export { default as EsContent } from "./usa-pagination~lang-es.json";
export { default as EsUnboundedContent } from "./usa-pagination~unbounded-lang-es.json";
