import Component from "./usa-list.twig";

export default {
  title: "Components/List",
};

const Template = (args) => Component(args);

export const List = Template.bind({});
